import { ChatbotResponse } from '../types';

// Fix: Cast import.meta to 'any' to bypass TypeScript's type checking for the 'env' property.
// In a Vite project, `import.meta.env` is correctly populated at runtime.
const API_BASE_URL = (import.meta as any).env.VITE_API_BASE_URL || '/api'; // Default to /api for proxying

export async function sendMessageToChatbot(message: string): Promise<ChatbotResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
      throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.message}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Failed to send message to chatbot:', error);
    throw error;
  }
}