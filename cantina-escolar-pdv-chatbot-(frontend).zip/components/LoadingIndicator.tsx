import React from 'react';

export const LoadingIndicator: React.FC = () => {
  return (
    <div className="flex justify-start mb-2 animate-pulse">
      <div className="max-w-[80%] rounded-xl p-3 bg-white shadow-md rounded-bl-none">
        <div className="flex space-x-1">
          <span className="w-2 h-2 bg-gray-400 rounded-full animate-[bounce_1.4s_infinite_ease-in-out_0s]"></span>
          <span className="w-2 h-2 bg-gray-400 rounded-full animate-[bounce_1.4s_infinite_ease-in-out_0.2s]"></span>
          <span className="w-2 h-2 bg-gray-400 rounded-full animate-[bounce_1.4s_infinite_ease-in-out_0.4s]"></span>
        </div>
      </div>
    </div>
  );
};
