import React from 'react';
import { Message, MessageSender } from '../types';

interface MessageBubbleProps {
  message: Message;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.sender === MessageSender.USER;
  const bubbleClasses = `
    max-w-[80%] rounded-xl p-3 shadow-md
    ${isUser
      ? 'bg-[#DCF8C6] self-end rounded-br-none' // User messages (light green)
      : 'bg-white self-start rounded-bl-none' // Bot messages (white)
    }
  `;

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-2`}>
      <div className={bubbleClasses}>
        <p className="text-sm break-words">{message.text}</p>
        {message.timestamp && (
          <span className="text-xs text-gray-500 ml-2 float-right clear-both">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        )}
      </div>
    </div>
  );
};
