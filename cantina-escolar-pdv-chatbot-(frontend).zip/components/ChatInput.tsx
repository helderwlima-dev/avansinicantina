import React, { useState } from 'react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-2">
      <input
        type="text"
        className="flex-1 p-3 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#075E54] bg-white text-gray-800 placeholder-gray-500"
        placeholder={isLoading ? "Enviando..." : "Digite sua mensagem..."}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        disabled={isLoading}
      />
      <button
        type="submit"
        className={`
          p-3 rounded-full bg-[#25D366] text-white flex items-center justify-center
          transition-colors duration-200
          ${isLoading ? 'opacity-60 cursor-not-allowed' : 'hover:bg-[#1DA851]'}
        `}
        disabled={isLoading}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className="w-6 h-6 transform rotate-90"
        >
          <path d="M10.894 2.553a1.125 1.125 0 00-1.788 0l-7.16 11.25c-.27.423-.083.987.39 1.144l2.43 1.196c.307.151.649.112.922-.093l4.337-3.219a1.125 1.125 0 011.275 0l4.337 3.22c.273.204.615.243.922.093l2.43-1.196c.473-.157.66-.721.39-1.144l-7.16-11.25z" />
        </svg>
      </button>
    </form>
  );
};
